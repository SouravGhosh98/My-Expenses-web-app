from django.shortcuts import render
from django.http import HttpResponse
import MySQLdb

def renderPage(req):
	return render(req,"login.html")

def login(req):
	#uname=req.POST["unm"]
	uname=req.POST.get("unm")
	pwd=req.POST.get("pass")
	conn=MySQLdb.connect("localhost","root","root","python21")
	query="select u_name from login where u_name='{}' and u_pass='{}'".format(uname,pwd)
	cur=conn.cursor()
	cur.execute(query)
	res=cur.fetchone()
	if(res):
		req.session['uname']=res
		response=render(req,"home.html",{'res':req.session['uname']})
		response.set_cookie("unm",req.session['uname'])
		return response
	else:
		return render(req,"login.html",{'res':"Invalid UserName & Password"})

def logout(req):
	first_test  = req.COOKIES['unm']
	del req.session['uname']
	return render(req,"login.html",{'res':'','cook':first_test}) 



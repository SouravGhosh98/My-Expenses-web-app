from django.contrib import admin
from django.urls import path
from myApp import views as v1
urlpatterns = [
    path('admin/', admin.site.urls),
    path('login',v1.renderPage),
    path('loginData',v1.login),
    path('logout',v1.logout)
   


  
   
]

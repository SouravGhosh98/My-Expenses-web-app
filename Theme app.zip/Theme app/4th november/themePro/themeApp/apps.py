from django.apps import AppConfig


class ThemeappConfig(AppConfig):
    name = 'themeApp'

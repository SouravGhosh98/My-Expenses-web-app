from django.shortcuts import render,redirect
from .models import User,Expense,Income

def loginPage(req):
	return render(req,"login.html")

def SignUp(req):
	return render(req,"signup.html")

def signupData(req):
	obj=User()
	obj.name=req.GET.get('uname')
	obj.password=req.GET.get('pwd')
	obj.phone=req.GET.get('phone')
	obj.email=req.GET.get('email')
	obj.save()
	return redirect("/")


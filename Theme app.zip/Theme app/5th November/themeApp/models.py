from django.db import models

class User(models.Model):
	name=models.CharField(max_length=50)
	password=models.CharField(max_length=50)
	phone=models.CharField(max_length=10)
	email=models.CharField(max_length=50)
	class meta:
		db_table="user"

class Expense(models.Model):
	time=models.TimeField()
	date=models.DateField()
	remark=models.CharField(max_length=100)
	amount=models.FloatField()
	category=models.CharField(max_length=100)

	class meta:
		db_table="expense"

class Income(models.Model):
	time=models.TimeField()
	date=models.DateField()
	remark=models.CharField(max_length=100)
	amount=models.FloatField()
	category=models.CharField(max_length=100)

	class meta:
		db_table="income"







from django.shortcuts import render

def renderPage(req):
	return render(req,"home.html")

def aboutPage(req):
	return render(req,"about.html")